# Changelog

## 2.1.1 2022-11-16
- Added support for php 8.1 and Laravel 9 

## 2.1.0 - 2021-01-25

- Added support for PHP 8

## 2.0.0 - 2020-10-13

- Added support for Laravel 8
- Added support for Livewire v2
- Added on/off flag for Day click event
- Added on/off flag for Event click event
- Added on/off flag for Drag and Drop event
- Added ability to automatically poll component with `pollMillis` and `pollAction` parameters
- Added tests 

## 1.0.0 - 2020-05-30

- Initial release
